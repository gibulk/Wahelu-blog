# Panduan Lengkap Deployment Blog Wahelu

Panduan ini menjelaskan langkah demi langkah cara men-deploy blog Wahelu menggunakan **GitHub**, **Supabase**, dan **Vercel**. Panduan ini dirancang agar mudah diikuti bahkan dari HP.

---

## Daftar Isi

1. [Persiapan Akun](#1-persiapan-akun)
2. [Setup Supabase (Database)](#2-setup-supabase-database)
3. [Upload ke GitHub](#3-upload-ke-github)
4. [Deploy ke Vercel](#4-deploy-ke-vercel)
5. [Membuat Akun Admin](#5-membuat-akun-admin)
6. [Penggunaan Admin Dashboard](#6-penggunaan-admin-dashboard)
7. [Konfigurasi Opsional](#7-konfigurasi-opsional)
8. [Troubleshooting](#8-troubleshooting)

---

## 1. Persiapan Akun

Pastikan Anda sudah memiliki akun di ketiga platform berikut (semua gratis):

| Platform | URL | Kegunaan |
|----------|-----|----------|
| **GitHub** | [github.com](https://github.com) | Menyimpan source code |
| **Supabase** | [supabase.com](https://supabase.com) | Database & Authentication |
| **Vercel** | [vercel.com](https://vercel.com) | Hosting & Deployment |

---

## 2. Setup Supabase (Database)

### 2.1 Buat Project Baru

1. Login ke [Supabase Dashboard](https://supabase.com/dashboard)
2. Klik **"New Project"**
3. Isi detail:
   - **Name**: `wahelu-blog`
   - **Database Password**: Buat password yang kuat (simpan baik-baik!)
   - **Region**: Pilih yang terdekat (misal: Southeast Asia - Singapore)
4. Klik **"Create new project"** dan tunggu hingga selesai

### 2.2 Jalankan SQL Schema

1. Di Supabase Dashboard, klik **"SQL Editor"** di sidebar kiri
2. Klik **"New Query"**
3. Copy-paste seluruh isi file `supabase/schema.sql` dari project ini
4. Klik **"Run"** (tombol hijau)
5. Pastikan tidak ada error

### 2.3 Buat Storage Bucket untuk Thumbnails

1. Di sidebar, klik **"Storage"**
2. Klik **"New Bucket"**
3. Isi:
   - **Name**: `thumbnails`
   - Centang **"Public bucket"**
4. Klik **"Create bucket"**
5. Klik bucket `thumbnails`, lalu klik tab **"Policies"**
6. Klik **"New Policy"** → pilih **"For full customization"**
7. Buat policy berikut:
   - **Policy name**: `Allow public read`
   - **Allowed operation**: SELECT
   - **Target roles**: (kosongkan = semua)
   - **Policy definition**: `true`
8. Buat policy lagi:
   - **Policy name**: `Allow authenticated upload`
   - **Allowed operation**: INSERT
   - **Target roles**: `authenticated`
   - **Policy definition**: `true`

### 2.4 Catat API Keys

1. Di sidebar, klik **"Settings"** → **"API"**
2. Catat nilai berikut (akan dipakai nanti):
   - **Project URL** (contoh: `https://xxxxx.supabase.co`)
   - **anon/public key** (panjang, dimulai dengan `eyJ...`)
   - **service_role key** (panjang, dimulai dengan `eyJ...`) — **JANGAN SHARE KE SIAPAPUN!**

---

## 3. Upload ke GitHub

### 3.1 Buat Repository Baru

1. Buka [github.com/new](https://github.com/new)
2. Isi:
   - **Repository name**: `wahelu-blog`
   - **Visibility**: Private (disarankan) atau Public
3. Klik **"Create repository"**

### 3.2 Upload Files

**Cara termudah dari HP:**

1. Buka repository yang baru dibuat
2. Klik **"uploading an existing file"** atau **"Add file"** → **"Upload files"**
3. Upload semua file dan folder dari project ini
4. Klik **"Commit changes"**

**Cara dari komputer (Terminal/Git Bash):**

```bash
cd wahelu-blog
git init
git add .
git commit -m "Initial commit: Wahelu Blog"
git branch -M main
git remote add origin https://github.com/USERNAME/wahelu-blog.git
git push -u origin main
```

> Ganti `USERNAME` dengan username GitHub Anda.

---

## 4. Deploy ke Vercel

### 4.1 Import Project

1. Login ke [Vercel Dashboard](https://vercel.com/dashboard)
2. Klik **"Add New..."** → **"Project"**
3. Pilih **"Import Git Repository"**
4. Hubungkan akun GitHub Anda jika belum
5. Pilih repository `wahelu-blog`
6. Klik **"Import"**

### 4.2 Konfigurasi Environment Variables

Di halaman konfigurasi sebelum deploy, tambahkan **Environment Variables** berikut:

| Key | Value |
|-----|-------|
| `NEXT_PUBLIC_SUPABASE_URL` | URL project Supabase Anda (dari langkah 2.4) |
| `NEXT_PUBLIC_SUPABASE_ANON_KEY` | Anon/public key Supabase (dari langkah 2.4) |
| `SUPABASE_SERVICE_ROLE_KEY` | Service role key Supabase (dari langkah 2.4) |
| `NEXT_PUBLIC_TIPPING_WALLET` | Alamat wallet Ethereum Anda untuk menerima tip (opsional) |

### 4.3 Deploy

1. Pastikan **Framework Preset** sudah terdeteksi sebagai **Next.js**
2. Klik **"Deploy"**
3. Tunggu proses build selesai (biasanya 2-5 menit)
4. Setelah selesai, Anda akan mendapat URL live (contoh: `wahelu-blog.vercel.app`)

---

## 5. Membuat Akun Admin

### 5.1 Buat User di Supabase

1. Buka Supabase Dashboard → **"Authentication"** → **"Users"**
2. Klik **"Add User"** → **"Create New User"**
3. Isi:
   - **Email**: email admin Anda (misal: `admin@wahelu.com`)
   - **Password**: password yang kuat
   - Centang **"Auto Confirm User"**
4. Klik **"Create User"**

### 5.2 Login ke Admin Dashboard

1. Buka `https://your-domain.vercel.app/admin`
2. Masukkan email dan password yang baru dibuat
3. Anda sekarang bisa mengelola artikel dan melihat subscribers!

---

## 6. Penggunaan Admin Dashboard

### 6.1 Membuat Artikel Baru

1. Login ke `/admin`
2. Klik tombol **"Artikel Baru"**
3. Isi form:
   - **Judul**: Judul artikel
   - **Ringkasan**: Deskripsi singkat (akan muncul di card)
   - **Kategori**: Pilih kategori yang sesuai
   - **Status**: `Draft` (simpan dulu) atau `Published` (langsung terbit)
   - **Thumbnail**: Upload gambar atau masukkan URL
   - **Peta Interaktif**: Centang jika ingin menampilkan peta, lalu isi koordinat
   - **Konten**: Tulis dalam format **Markdown**
4. Klik **"Simpan Artikel"**

### 6.2 Format Markdown untuk Konten

```markdown
## Judul Bagian

Paragraf biasa dengan **teks tebal** dan *teks miring*.

### Sub-judul

- Item list 1
- Item list 2
- Item list 3

> Ini adalah kutipan/blockquote

[Teks Link](https://url.com)

![Alt gambar](https://url-gambar.com/gambar.jpg)
```

### 6.3 Mengelola Artikel

- **Edit**: Klik ikon pensil pada artikel
- **Hapus**: Klik ikon tempat sampah
- **Lihat**: Klik ikon mata (hanya untuk artikel published)
- **Draft → Published**: Edit artikel, ubah status ke "Published", lalu simpan

### 6.4 Melihat Subscribers

1. Di admin dashboard, klik tab **"Subscribers"**
2. Anda bisa melihat daftar email dan tanggal bergabung
3. Untuk menghapus subscriber, klik ikon tempat sampah

---

## 7. Konfigurasi Opsional

### 7.1 Custom Domain

1. Di Vercel Dashboard, buka project Anda
2. Klik **"Settings"** → **"Domains"**
3. Tambahkan domain custom Anda
4. Ikuti instruksi untuk mengatur DNS

### 7.2 Web3 Tipping

Untuk mengaktifkan fitur tipping kripto:

1. Pastikan Anda memiliki wallet MetaMask
2. Copy alamat wallet Anda
3. Di Vercel, tambahkan environment variable:
   - Key: `NEXT_PUBLIC_TIPPING_WALLET`
   - Value: Alamat wallet Anda (contoh: `0x1234...abcd`)
4. Redeploy project

### 7.3 Menambah Kategori Baru

Edit file `lib/types.ts` dan tambahkan kategori baru di array `CATEGORIES`:

```typescript
export const CATEGORIES = [
  "Geopolitik Asia-Pasifik",
  "Ekonomi-Politik Global",
  "Web3 & Desentralisasi",
  "Konflik & Perbatasan",
  "Kartografi & Geografi",
  "Kategori Baru Anda",  // tambahkan di sini
] as const;
```

---

## 8. Troubleshooting

### Build Error di Vercel

- Pastikan semua environment variables sudah diisi dengan benar
- Cek apakah ada typo di URL Supabase atau API keys
- Pastikan SQL schema sudah dijalankan di Supabase

### Tidak Bisa Login Admin

- Pastikan user sudah dibuat di Supabase Authentication
- Pastikan "Auto Confirm User" dicentang saat membuat user
- Coba reset password dari Supabase Dashboard

### Artikel Tidak Muncul

- Pastikan status artikel adalah "published" (bukan "draft")
- Tunggu hingga 60 detik (halaman di-cache dengan ISR)
- Coba refresh halaman atau buka di incognito mode

### Upload Gambar Gagal

- Pastikan bucket "thumbnails" sudah dibuat di Supabase Storage
- Pastikan policies sudah dikonfigurasi (lihat langkah 2.3)
- Ukuran file maksimal default adalah 50MB

### Peta Tidak Muncul

- Pastikan "Tampilkan Peta Interaktif" dicentang di editor artikel
- Pastikan latitude dan longitude diisi dengan benar
- Peta menggunakan OpenStreetMap (gratis, tidak perlu API key)

---

## Struktur File Project

```
wahelu-blog/
├── app/
│   ├── admin/
│   │   ├── layout.tsx          # Admin auth guard & login form
│   │   └── page.tsx            # Admin dashboard (CRUD articles & subscribers)
│   ├── articles/
│   │   ├── [slug]/
│   │   │   ├── page.tsx        # Article detail page (server)
│   │   │   └── ArticleContent.tsx  # Article content with map & tipping (client)
│   │   └── page.tsx            # Articles listing with category filter
│   ├── api/
│   │   ├── articles/
│   │   │   └── route.ts        # REST API for articles CRUD
│   │   ├── subscribers/
│   │   │   └── route.ts        # REST API for subscribers
│   │   └── upload/
│   │       └── route.ts        # Image upload to Supabase Storage
│   ├── globals.css             # Global styles + Tailwind
│   ├── layout.tsx              # Root layout with theme provider
│   ├── loading.tsx             # Loading spinner
│   ├── not-found.tsx           # 404 page
│   └── page.tsx                # Home page
├── components/
│   ├── ArticleCard.tsx         # Article card component
│   ├── Footer.tsx              # Site footer
│   ├── MapView.tsx             # Interactive Leaflet map
│   ├── Navbar.tsx              # Navigation bar with dark mode toggle
│   ├── Newsletter.tsx          # Newsletter subscription form
│   ├── ThemeProvider.tsx       # Dark/Light theme provider
│   └── Web3Tipping.tsx         # MetaMask tipping component
├── lib/
│   ├── supabase.ts             # Supabase client configuration
│   ├── types.ts                # TypeScript types & categories
│   └── utils.ts                # Utility functions
├── supabase/
│   └── schema.sql              # Database schema & seed data
├── .env.local.example          # Environment variables template
├── .gitignore
├── middleware.ts                # Next.js middleware
├── next.config.mjs             # Next.js configuration
├── package.json                # Dependencies
├── postcss.config.mjs          # PostCSS config
├── tailwind.config.ts          # Tailwind CSS config
├── tsconfig.json               # TypeScript config
└── PANDUAN.md                  # Panduan ini
```

---

## Fitur yang Tersedia

| Fitur | Deskripsi |
|-------|-----------|
| **Hero Section** | Profil Wahelu sebagai analis geopolitik & kontributor Web3 |
| **Artikel dengan Kategorisasi** | 5 kategori: Geopolitik Asia-Pasifik, Ekonomi-Politik Global, Web3 & Desentralisasi, Konflik & Perbatasan, Kartografi & Geografi |
| **Peta Dunia Interaktif** | Leaflet/OpenStreetMap yang bisa disematkan per artikel |
| **Admin Dashboard** | CRUD artikel lengkap, kelola subscribers, upload thumbnail |
| **Dark/Light Mode** | Toggle tema gelap/terang |
| **Newsletter** | Form subscription untuk pembaca |
| **Web3 Tipping** | Integrasi MetaMask untuk donasi ETH |
| **Markdown Content** | Tulis artikel dalam format Markdown |
| **Responsive Design** | Optimal di HP dan desktop |
| **ISR (Incremental Static Regeneration)** | Halaman di-cache dan di-update otomatis setiap 60 detik |

---

**Selamat! Blog Wahelu Anda siap digunakan.** 🎉

Jika ada pertanyaan atau kendala, silakan buka issue di repository GitHub Anda.
