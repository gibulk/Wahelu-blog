import type { Metadata } from "next";
import { ThemeProvider } from "@/components/ThemeProvider";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import "./globals.css";

export const metadata: Metadata = {
  title: "Wahelu — Analisis Geopolitik & Web3",
  description:
    "Platform analisis mendalam mengenai dinamika global, konflik perbatasan, kartografi, dan ekosistem Web3 oleh Wahelu.",
  keywords: ["geopolitik", "web3", "analisis", "kartografi", "blockchain", "wahelu"],
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="id" suppressHydrationWarning>
      <body className="min-h-screen flex flex-col">
        <ThemeProvider>
          <Navbar />
          <main className="flex-1">{children}</main>
          <Footer />
        </ThemeProvider>
      </body>
    </html>
  );
}
