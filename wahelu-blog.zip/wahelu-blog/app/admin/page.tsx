"use client";

import { useState, useEffect } from "react";
import { Article, Subscriber, CATEGORIES } from "@/lib/types";
import { formatDate } from "@/lib/utils";
import {
  Plus,
  Edit3,
  Trash2,
  Eye,
  FileText,
  Users,
  Loader2,
  Save,
  X,
  Upload,
  Map,
} from "lucide-react";

type Tab = "articles" | "subscribers" | "editor";

export default function AdminPage() {
  const [tab, setTab] = useState<Tab>("articles");
  const [articles, setArticles] = useState<Article[]>([]);
  const [subscribers, setSubscribers] = useState<Subscriber[]>([]);
  const [loading, setLoading] = useState(true);
  const [editingArticle, setEditingArticle] = useState<Partial<Article> | null>(null);
  const [saving, setSaving] = useState(false);
  const [uploading, setUploading] = useState(false);

  useEffect(() => {
    fetchData();
  }, []);

  const fetchData = async () => {
    setLoading(true);
    const [articlesRes, subscribersRes] = await Promise.all([
      fetch("/api/articles?all=true"),
      fetch("/api/subscribers"),
    ]);
    const articlesData = await articlesRes.json();
    const subscribersData = await subscribersRes.json();
    setArticles(Array.isArray(articlesData) ? articlesData : []);
    setSubscribers(Array.isArray(subscribersData) ? subscribersData : []);
    setLoading(false);
  };

  const handleNewArticle = () => {
    setEditingArticle({
      title: "",
      excerpt: "",
      content: "",
      category: CATEGORIES[0],
      thumbnail_url: "",
      status: "draft",
      show_map: false,
      map_lat: 0,
      map_lng: 0,
      map_zoom: 5,
    });
    setTab("editor");
  };

  const handleEditArticle = (article: Article) => {
    setEditingArticle({ ...article });
    setTab("editor");
  };

  const handleSaveArticle = async () => {
    if (!editingArticle?.title) return;
    setSaving(true);

    try {
      const method = editingArticle.id ? "PUT" : "POST";
      const res = await fetch("/api/articles", {
        method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(editingArticle),
      });

      if (res.ok) {
        await fetchData();
        setEditingArticle(null);
        setTab("articles");
      }
    } catch (err) {
      console.error("Save failed:", err);
    }
    setSaving(false);
  };

  const handleDeleteArticle = async (id: string) => {
    if (!confirm("Yakin ingin menghapus artikel ini?")) return;

    await fetch(`/api/articles?id=${id}`, { method: "DELETE" });
    await fetchData();
  };

  const handleDeleteSubscriber = async (id: string) => {
    if (!confirm("Yakin ingin menghapus subscriber ini?")) return;

    await fetch(`/api/subscribers?id=${id}`, { method: "DELETE" });
    await fetchData();
  };

  const handleUploadThumbnail = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setUploading(true);
    const formData = new FormData();
    formData.append("file", file);

    try {
      const res = await fetch("/api/upload", { method: "POST", body: formData });
      const data = await res.json();
      if (data.url) {
        setEditingArticle((prev) => prev ? { ...prev, thumbnail_url: data.url } : null);
      }
    } catch (err) {
      console.error("Upload failed:", err);
    }
    setUploading(false);
  };

  if (loading) {
    return (
      <div className="min-h-[40vh] flex items-center justify-center">
        <Loader2 className="w-8 h-8 animate-spin text-primary-600" />
      </div>
    );
  }

  return (
    <div className="container-blog py-8">
      {/* Stats */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
        <div className="card p-4 text-center">
          <FileText className="w-6 h-6 text-primary-600 mx-auto mb-2" />
          <p className="text-2xl font-bold text-gray-900 dark:text-dark-text">{articles.length}</p>
          <p className="text-xs text-gray-500 dark:text-dark-muted">Total Artikel</p>
        </div>
        <div className="card p-4 text-center">
          <Eye className="w-6 h-6 text-green-600 mx-auto mb-2" />
          <p className="text-2xl font-bold text-gray-900 dark:text-dark-text">
            {articles.filter((a) => a.status === "published").length}
          </p>
          <p className="text-xs text-gray-500 dark:text-dark-muted">Published</p>
        </div>
        <div className="card p-4 text-center">
          <Edit3 className="w-6 h-6 text-yellow-600 mx-auto mb-2" />
          <p className="text-2xl font-bold text-gray-900 dark:text-dark-text">
            {articles.filter((a) => a.status === "draft").length}
          </p>
          <p className="text-xs text-gray-500 dark:text-dark-muted">Draft</p>
        </div>
        <div className="card p-4 text-center">
          <Users className="w-6 h-6 text-blue-600 mx-auto mb-2" />
          <p className="text-2xl font-bold text-gray-900 dark:text-dark-text">{subscribers.length}</p>
          <p className="text-xs text-gray-500 dark:text-dark-muted">Subscribers</p>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex items-center gap-4 mb-6 border-b border-gray-200 dark:border-dark-border">
        <button
          onClick={() => { setTab("articles"); setEditingArticle(null); }}
          className={`pb-3 text-sm font-medium border-b-2 transition-colors ${
            tab === "articles"
              ? "border-primary-600 text-primary-700 dark:text-primary-400"
              : "border-transparent text-gray-500 hover:text-gray-700 dark:text-dark-muted"
          }`}
        >
          Artikel
        </button>
        <button
          onClick={() => { setTab("subscribers"); setEditingArticle(null); }}
          className={`pb-3 text-sm font-medium border-b-2 transition-colors ${
            tab === "subscribers"
              ? "border-primary-600 text-primary-700 dark:text-primary-400"
              : "border-transparent text-gray-500 hover:text-gray-700 dark:text-dark-muted"
          }`}
        >
          Subscribers
        </button>
        {tab === "editor" && (
          <span className="pb-3 text-sm font-medium border-b-2 border-primary-600 text-primary-700 dark:text-primary-400">
            {editingArticle?.id ? "Edit Artikel" : "Artikel Baru"}
          </span>
        )}
      </div>

      {/* Articles Tab */}
      {tab === "articles" && (
        <div>
          <div className="flex justify-between items-center mb-4">
            <h2 className="font-serif text-xl font-bold text-gray-900 dark:text-dark-text">
              Daftar Artikel
            </h2>
            <button onClick={handleNewArticle} className="btn-primary text-sm">
              <Plus className="w-4 h-4 mr-1" /> Artikel Baru
            </button>
          </div>

          <div className="space-y-3">
            {articles.map((article) => (
              <div
                key={article.id}
                className="card p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3"
              >
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 mb-1">
                    <span
                      className={`badge text-xs ${
                        article.status === "published"
                          ? "bg-green-100 text-green-800 dark:bg-green-900/30 dark:text-green-300"
                          : "bg-yellow-100 text-yellow-800 dark:bg-yellow-900/30 dark:text-yellow-300"
                      }`}
                    >
                      {article.status}
                    </span>
                    <span className="badge-category text-xs">{article.category}</span>
                  </div>
                  <h3 className="font-semibold text-gray-900 dark:text-dark-text truncate">
                    {article.title}
                  </h3>
                  <p className="text-xs text-gray-500 dark:text-dark-muted mt-1">
                    {formatDate(article.created_at)}
                  </p>
                </div>
                <div className="flex items-center gap-2">
                  {article.status === "published" && (
                    <a
                      href={`/articles/${article.slug}`}
                      target="_blank"
                      className="btn-ghost p-2 text-sm"
                      title="Lihat"
                    >
                      <Eye className="w-4 h-4" />
                    </a>
                  )}
                  <button
                    onClick={() => handleEditArticle(article)}
                    className="btn-ghost p-2 text-sm"
                    title="Edit"
                  >
                    <Edit3 className="w-4 h-4" />
                  </button>
                  <button
                    onClick={() => handleDeleteArticle(article.id)}
                    className="btn-ghost p-2 text-sm text-red-500 hover:text-red-700"
                    title="Hapus"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
            ))}

            {articles.length === 0 && (
              <div className="text-center py-12 text-gray-500 dark:text-dark-muted">
                Belum ada artikel. Klik "Artikel Baru" untuk mulai menulis.
              </div>
            )}
          </div>
        </div>
      )}

      {/* Subscribers Tab */}
      {tab === "subscribers" && (
        <div>
          <h2 className="font-serif text-xl font-bold text-gray-900 dark:text-dark-text mb-4">
            Daftar Subscribers ({subscribers.length})
          </h2>
          <div className="space-y-2">
            {subscribers.map((sub) => (
              <div
                key={sub.id}
                className="card p-4 flex items-center justify-between"
              >
                <div>
                  <p className="font-medium text-gray-900 dark:text-dark-text">{sub.email}</p>
                  <p className="text-xs text-gray-500 dark:text-dark-muted">
                    Bergabung {formatDate(sub.created_at)}
                  </p>
                </div>
                <button
                  onClick={() => handleDeleteSubscriber(sub.id)}
                  className="btn-ghost p-2 text-red-500 hover:text-red-700"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            ))}

            {subscribers.length === 0 && (
              <div className="text-center py-12 text-gray-500 dark:text-dark-muted">
                Belum ada subscriber.
              </div>
            )}
          </div>
        </div>
      )}

      {/* Editor Tab */}
      {tab === "editor" && editingArticle && (
        <div className="max-w-3xl">
          <div className="flex items-center justify-between mb-6">
            <h2 className="font-serif text-xl font-bold text-gray-900 dark:text-dark-text">
              {editingArticle.id ? "Edit Artikel" : "Artikel Baru"}
            </h2>
            <button
              onClick={() => { setEditingArticle(null); setTab("articles"); }}
              className="btn-ghost p-2"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          <div className="space-y-5">
            {/* Title */}
            <div>
              <label className="block text-sm font-medium text-gray-700 dark:text-dark-muted mb-1">
                Judul Artikel *
              </label>
              <input
                type="text"
                value={editingArticle.title || ""}
                onChange={(e) =>
                  setEditingArticle({ ...editingArticle, title: e.target.value })
                }
                className="input-field text-lg font-serif"
                placeholder="Masukkan judul artikel..."
              />
            </div>

            {/* Excerpt */}
            <div>
              <label className="block text-sm font-medium text-gray-700 dark:text-dark-muted mb-1">
                Ringkasan / Excerpt
              </label>
              <textarea
                value={editingArticle.excerpt || ""}
                onChange={(e) =>
                  setEditingArticle({ ...editingArticle, excerpt: e.target.value })
                }
                className="input-field h-20 resize-none"
                placeholder="Ringkasan singkat artikel..."
              />
            </div>

            {/* Category & Status */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-dark-muted mb-1">
                  Kategori
                </label>
                <select
                  value={editingArticle.category || CATEGORIES[0]}
                  onChange={(e) =>
                    setEditingArticle({ ...editingArticle, category: e.target.value })
                  }
                  className="input-field"
                >
                  {CATEGORIES.map((cat) => (
                    <option key={cat} value={cat}>
                      {cat}
                    </option>
                  ))}
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-dark-muted mb-1">
                  Status
                </label>
                <select
                  value={editingArticle.status || "draft"}
                  onChange={(e) =>
                    setEditingArticle({
                      ...editingArticle,
                      status: e.target.value as "draft" | "published",
                    })
                  }
                  className="input-field"
                >
                  <option value="draft">Draft</option>
                  <option value="published">Published</option>
                </select>
              </div>
            </div>

            {/* Thumbnail */}
            <div>
              <label className="block text-sm font-medium text-gray-700 dark:text-dark-muted mb-1">
                Thumbnail
              </label>
              <div className="flex items-center gap-3">
                <input
                  type="text"
                  value={editingArticle.thumbnail_url || ""}
                  onChange={(e) =>
                    setEditingArticle({ ...editingArticle, thumbnail_url: e.target.value })
                  }
                  className="input-field flex-1"
                  placeholder="URL gambar atau upload..."
                />
                <label className="btn-secondary text-sm cursor-pointer flex items-center gap-1">
                  {uploading ? (
                    <Loader2 className="w-4 h-4 animate-spin" />
                  ) : (
                    <Upload className="w-4 h-4" />
                  )}
                  Upload
                  <input
                    type="file"
                    accept="image/*"
                    onChange={handleUploadThumbnail}
                    className="hidden"
                  />
                </label>
              </div>
              {editingArticle.thumbnail_url && (
                <img
                  src={editingArticle.thumbnail_url}
                  alt="Preview"
                  className="mt-2 h-32 w-auto rounded-lg object-cover"
                />
              )}
            </div>

            {/* Map Settings */}
            <div className="card p-4">
              <label className="flex items-center gap-2 cursor-pointer mb-3">
                <input
                  type="checkbox"
                  checked={editingArticle.show_map || false}
                  onChange={(e) =>
                    setEditingArticle({ ...editingArticle, show_map: e.target.checked })
                  }
                  className="w-4 h-4 rounded border-gray-300 text-primary-600 focus:ring-primary-500"
                />
                <Map className="w-4 h-4 text-gray-600 dark:text-dark-muted" />
                <span className="text-sm font-medium text-gray-700 dark:text-dark-muted">
                  Tampilkan Peta Interaktif
                </span>
              </label>

              {editingArticle.show_map && (
                <div className="grid grid-cols-3 gap-3">
                  <div>
                    <label className="block text-xs text-gray-500 mb-1">Latitude</label>
                    <input
                      type="number"
                      step="0.01"
                      value={editingArticle.map_lat || 0}
                      onChange={(e) =>
                        setEditingArticle({
                          ...editingArticle,
                          map_lat: parseFloat(e.target.value),
                        })
                      }
                      className="input-field text-sm"
                    />
                  </div>
                  <div>
                    <label className="block text-xs text-gray-500 mb-1">Longitude</label>
                    <input
                      type="number"
                      step="0.01"
                      value={editingArticle.map_lng || 0}
                      onChange={(e) =>
                        setEditingArticle({
                          ...editingArticle,
                          map_lng: parseFloat(e.target.value),
                        })
                      }
                      className="input-field text-sm"
                    />
                  </div>
                  <div>
                    <label className="block text-xs text-gray-500 mb-1">Zoom</label>
                    <input
                      type="number"
                      min="1"
                      max="18"
                      value={editingArticle.map_zoom || 5}
                      onChange={(e) =>
                        setEditingArticle({
                          ...editingArticle,
                          map_zoom: parseInt(e.target.value),
                        })
                      }
                      className="input-field text-sm"
                    />
                  </div>
                </div>
              )}
            </div>

            {/* Content */}
            <div>
              <label className="block text-sm font-medium text-gray-700 dark:text-dark-muted mb-1">
                Konten (Markdown) *
              </label>
              <textarea
                value={editingArticle.content || ""}
                onChange={(e) =>
                  setEditingArticle({ ...editingArticle, content: e.target.value })
                }
                className="input-field h-96 resize-y font-mono text-sm"
                placeholder="Tulis konten artikel dalam format Markdown..."
              />
              <p className="text-xs text-gray-500 dark:text-dark-muted mt-1">
                Mendukung format Markdown: ## Heading, **bold**, *italic*, - list, dll.
              </p>
            </div>

            {/* Actions */}
            <div className="flex items-center gap-3 pt-4">
              <button
                onClick={handleSaveArticle}
                disabled={saving || !editingArticle.title}
                className="btn-primary flex items-center gap-2"
              >
                {saving ? (
                  <Loader2 className="w-4 h-4 animate-spin" />
                ) : (
                  <Save className="w-4 h-4" />
                )}
                {editingArticle.id ? "Update Artikel" : "Simpan Artikel"}
              </button>
              <button
                onClick={() => { setEditingArticle(null); setTab("articles"); }}
                className="btn-ghost"
              >
                Batal
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
