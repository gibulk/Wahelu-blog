import { createServiceClient } from "@/lib/supabase";
import ArticleCard from "@/components/ArticleCard";
import Newsletter from "@/components/Newsletter";
import Link from "next/link";
import { ArrowRight, Globe, BookOpen, Blocks } from "lucide-react";
import { Article } from "@/lib/types";

export const revalidate = 60; // ISR: revalidate every 60 seconds

async function getArticles(): Promise<Article[]> {
  const supabase = createServiceClient();
  const { data } = await supabase
    .from("articles")
    .select("*")
    .eq("status", "published")
    .order("published_at", { ascending: false })
    .limit(6);
  return (data as Article[]) || [];
}

export default async function HomePage() {
  const articles = await getArticles();
  const featuredArticle = articles[0];
  const recentArticles = articles.slice(1, 5);

  return (
    <div>
      {/* Hero Section */}
      <section className="relative overflow-hidden bg-gradient-to-br from-gray-50 via-white to-primary-50 dark:from-dark-bg dark:via-dark-bg dark:to-primary-900/10">
        <div className="container-blog py-20 md:py-32">
          <div className="max-w-3xl">
            <div className="flex items-center gap-2 mb-6">
              <span className="badge bg-primary-100 text-primary-800 dark:bg-primary-900/30 dark:text-primary-300 text-xs">
                Analisis & Insight
              </span>
            </div>

            <h1 className="font-serif text-4xl md:text-6xl font-bold text-gray-900 dark:text-dark-text leading-tight mb-6">
              Memahami Dunia Melalui{" "}
              <span className="text-primary-700 dark:text-primary-400">
                Geopolitik
              </span>{" "}
              &{" "}
              <span className="text-primary-700 dark:text-primary-400">
                Web3
              </span>
            </h1>

            <p className="text-lg md:text-xl text-gray-600 dark:text-dark-muted leading-relaxed mb-8 max-w-2xl">
              Saya <strong className="text-gray-900 dark:text-dark-text">Wahelu</strong> — penulis, analis geopolitik, dan kontributor Web3.
              Di sini saya membagikan analisis mendalam tentang dinamika global,
              konflik perbatasan, kartografi, dan persimpangannya dengan teknologi desentralisasi.
            </p>

            <div className="flex flex-wrap gap-4">
              <Link href="/articles" className="btn-primary">
                Jelajahi Artikel
                <ArrowRight className="w-4 h-4 ml-2" />
              </Link>
              <Link href="/articles?category=Web3+%26+Desentralisasi" className="btn-secondary">
                Web3 Insights
              </Link>
            </div>
          </div>
        </div>

        {/* Decorative elements */}
        <div className="absolute top-20 right-10 w-72 h-72 bg-primary-200/20 dark:bg-primary-800/10 rounded-full blur-3xl" />
        <div className="absolute bottom-10 right-40 w-48 h-48 bg-primary-300/15 dark:bg-primary-700/10 rounded-full blur-2xl" />
      </section>

      {/* Expertise Pillars */}
      <section className="container-blog py-16">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {[
            {
              icon: Globe,
              title: "Geopolitik & Geografi",
              desc: "Analisis mendalam tentang dinamika kekuasaan global, konflik perbatasan, dan kartografi modern.",
            },
            {
              icon: Blocks,
              title: "Web3 & Desentralisasi",
              desc: "Eksplorasi teknologi blockchain, DeFi, dan implikasinya terhadap tata kelola global.",
            },
            {
              icon: BookOpen,
              title: "Riset & Analisis",
              desc: "Pendekatan berbasis data dan riset untuk memahami isu-isu kompleks dunia kontemporer.",
            },
          ].map((item) => (
            <div
              key={item.title}
              className="card p-6 text-center hover:border-primary-300 dark:hover:border-primary-700"
            >
              <item.icon className="w-8 h-8 text-primary-600 dark:text-primary-400 mx-auto mb-4" />
              <h3 className="font-serif font-semibold text-gray-900 dark:text-dark-text mb-2">
                {item.title}
              </h3>
              <p className="text-sm text-gray-600 dark:text-dark-muted">{item.desc}</p>
            </div>
          ))}
        </div>
      </section>

      {/* Featured Article */}
      {featuredArticle && (
        <section className="container-blog py-8">
          <div className="flex items-center justify-between mb-8">
            <h2 className="font-serif text-2xl md:text-3xl font-bold text-gray-900 dark:text-dark-text">
              Artikel Unggulan
            </h2>
          </div>
          <ArticleCard article={featuredArticle} featured />
        </section>
      )}

      {/* Recent Articles */}
      {recentArticles.length > 0 && (
        <section className="container-blog py-8">
          <div className="flex items-center justify-between mb-8">
            <h2 className="font-serif text-2xl md:text-3xl font-bold text-gray-900 dark:text-dark-text">
              Artikel Terbaru
            </h2>
            <Link
              href="/articles"
              className="text-sm font-medium text-primary-700 dark:text-primary-400 hover:underline flex items-center gap-1"
            >
              Lihat Semua <ArrowRight className="w-4 h-4" />
            </Link>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {recentArticles.map((article) => (
              <ArticleCard key={article.id} article={article} />
            ))}
          </div>
        </section>
      )}

      {/* Newsletter */}
      <section className="container-blog py-16">
        <Newsletter />
      </section>
    </div>
  );
}
