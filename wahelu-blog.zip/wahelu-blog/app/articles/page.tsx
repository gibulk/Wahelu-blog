import { createServiceClient } from "@/lib/supabase";
import ArticleCard from "@/components/ArticleCard";
import Newsletter from "@/components/Newsletter";
import { Article, CATEGORIES } from "@/lib/types";
import Link from "next/link";

export const revalidate = 60;

interface Props {
  searchParams: { category?: string };
}

async function getArticles(category?: string): Promise<Article[]> {
  const supabase = createServiceClient();
  let query = supabase
    .from("articles")
    .select("*")
    .eq("status", "published")
    .order("published_at", { ascending: false });

  if (category) {
    query = query.eq("category", category);
  }

  const { data } = await query;
  return (data as Article[]) || [];
}

export default async function ArticlesPage({ searchParams }: Props) {
  const activeCategory = searchParams.category || "";
  const articles = await getArticles(activeCategory || undefined);

  return (
    <div className="container-blog py-12">
      {/* Header */}
      <div className="mb-10">
        <h1 className="font-serif text-3xl md:text-4xl font-bold text-gray-900 dark:text-dark-text mb-3">
          Semua Artikel
        </h1>
        <p className="text-gray-600 dark:text-dark-muted">
          Jelajahi analisis mendalam tentang geopolitik, geografi, dan Web3.
        </p>
      </div>

      {/* Category Filter */}
      <div className="flex flex-wrap gap-2 mb-10">
        <Link
          href="/articles"
          className={`badge transition-colors ${
            !activeCategory
              ? "bg-primary-700 text-white dark:bg-primary-600"
              : "bg-gray-100 text-gray-700 hover:bg-gray-200 dark:bg-dark-card dark:text-dark-muted dark:hover:bg-dark-border"
          }`}
        >
          Semua
        </Link>
        {CATEGORIES.map((cat) => (
          <Link
            key={cat}
            href={`/articles?category=${encodeURIComponent(cat)}`}
            className={`badge transition-colors ${
              activeCategory === cat
                ? "bg-primary-700 text-white dark:bg-primary-600"
                : "bg-gray-100 text-gray-700 hover:bg-gray-200 dark:bg-dark-card dark:text-dark-muted dark:hover:bg-dark-border"
            }`}
          >
            {cat}
          </Link>
        ))}
      </div>

      {/* Articles Grid */}
      {articles.length > 0 ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {articles.map((article) => (
            <ArticleCard key={article.id} article={article} />
          ))}
        </div>
      ) : (
        <div className="text-center py-20">
          <p className="text-gray-500 dark:text-dark-muted text-lg">
            Belum ada artikel{activeCategory ? ` dalam kategori "${activeCategory}"` : ""}.
          </p>
        </div>
      )}

      {/* Newsletter */}
      <div className="mt-16">
        <Newsletter />
      </div>
    </div>
  );
}
