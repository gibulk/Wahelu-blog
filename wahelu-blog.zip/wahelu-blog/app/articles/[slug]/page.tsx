import { createServiceClient } from "@/lib/supabase";
import { formatDate } from "@/lib/utils";
import { Article } from "@/lib/types";
import { notFound } from "next/navigation";
import Link from "next/link";
import { Calendar, ArrowLeft, Tag } from "lucide-react";
import ArticleContent from "./ArticleContent";

export const revalidate = 60;

interface Props {
  params: { slug: string };
}

async function getArticle(slug: string): Promise<Article | null> {
  const supabase = createServiceClient();
  const { data } = await supabase
    .from("articles")
    .select("*")
    .eq("slug", slug)
    .eq("status", "published")
    .single();
  return data as Article | null;
}

async function getRelatedArticles(category: string, currentId: string): Promise<Article[]> {
  const supabase = createServiceClient();
  const { data } = await supabase
    .from("articles")
    .select("*")
    .eq("status", "published")
    .eq("category", category)
    .neq("id", currentId)
    .order("published_at", { ascending: false })
    .limit(3);
  return (data as Article[]) || [];
}

export async function generateMetadata({ params }: Props) {
  const article = await getArticle(params.slug);
  if (!article) return { title: "Artikel Tidak Ditemukan" };
  return {
    title: `${article.title} — Wahelu`,
    description: article.excerpt,
  };
}

export default async function ArticleDetailPage({ params }: Props) {
  const article = await getArticle(params.slug);
  if (!article) notFound();

  const relatedArticles = await getRelatedArticles(article.category, article.id);

  return (
    <div className="container-blog py-8 md:py-12">
      {/* Back Link */}
      <Link
        href="/articles"
        className="inline-flex items-center gap-2 text-sm text-gray-500 dark:text-dark-muted hover:text-primary-700 dark:hover:text-primary-400 transition-colors mb-8"
      >
        <ArrowLeft className="w-4 h-4" />
        Kembali ke Artikel
      </Link>

      <article className="max-w-4xl mx-auto">
        {/* Header */}
        <header className="mb-10">
          <div className="flex items-center gap-3 mb-4">
            <span className="badge-category">
              <Tag className="w-3 h-3 mr-1" />
              {article.category}
            </span>
          </div>

          <h1 className="font-serif text-3xl md:text-5xl font-bold text-gray-900 dark:text-dark-text leading-tight mb-4">
            {article.title}
          </h1>

          <p className="text-lg text-gray-600 dark:text-dark-muted leading-relaxed mb-6">
            {article.excerpt}
          </p>

          <div className="flex items-center gap-4 text-sm text-gray-500 dark:text-dark-muted">
            <div className="flex items-center gap-1.5">
              <Calendar className="w-4 h-4" />
              {article.published_at ? formatDate(article.published_at) : "Draft"}
            </div>
            <span>•</span>
            <span>Oleh Wahelu</span>
          </div>
        </header>

        {/* Thumbnail */}
        {article.thumbnail_url && (
          <div className="mb-10 rounded-xl overflow-hidden">
            <img
              src={article.thumbnail_url}
              alt={article.title}
              className="w-full h-auto max-h-[500px] object-cover"
            />
          </div>
        )}

        {/* Client-side content with Map and Tipping */}
        <ArticleContent article={article} />
      </article>

      {/* Related Articles */}
      {relatedArticles.length > 0 && (
        <section className="max-w-4xl mx-auto mt-16 pt-10 border-t border-gray-200 dark:border-dark-border">
          <h2 className="font-serif text-2xl font-bold text-gray-900 dark:text-dark-text mb-6">
            Artikel Terkait
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {relatedArticles.map((related) => (
              <Link
                key={related.id}
                href={`/articles/${related.slug}`}
                className="card p-4 group"
              >
                <span className="badge-category text-xs mb-2">{related.category}</span>
                <h3 className="font-serif font-semibold text-sm text-gray-900 dark:text-dark-text group-hover:text-primary-700 dark:group-hover:text-primary-400 transition-colors">
                  {related.title}
                </h3>
              </Link>
            ))}
          </div>
        </section>
      )}
    </div>
  );
}
