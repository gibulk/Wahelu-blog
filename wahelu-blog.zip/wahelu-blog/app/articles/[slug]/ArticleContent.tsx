"use client";

import dynamic from "next/dynamic";
import ReactMarkdown from "react-markdown";
import remarkGfm from "remark-gfm";
import rehypeRaw from "rehype-raw";
import { Article } from "@/lib/types";
import Web3Tipping from "@/components/Web3Tipping";

const MapView = dynamic(() => import("@/components/MapView"), { ssr: false });

interface Props {
  article: Article;
}

export default function ArticleContent({ article }: Props) {
  return (
    <div className="grid grid-cols-1 lg:grid-cols-[1fr_300px] gap-10">
      {/* Main Content */}
      <div className="article-content min-w-0">
        <ReactMarkdown remarkPlugins={[remarkGfm]} rehypePlugins={[rehypeRaw]}>
          {article.content}
        </ReactMarkdown>
      </div>

      {/* Sidebar */}
      <aside className="space-y-6">
        {/* Map */}
        {article.show_map && article.map_lat && article.map_lng && (
          <MapView
            lat={article.map_lat}
            lng={article.map_lng}
            zoom={article.map_zoom || 5}
          />
        )}

        {/* Web3 Tipping */}
        <Web3Tipping />
      </aside>
    </div>
  );
}
