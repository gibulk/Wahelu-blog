import Link from "next/link";
import { Home } from "lucide-react";

export default function NotFound() {
  return (
    <div className="min-h-[60vh] flex items-center justify-center px-4">
      <div className="text-center">
        <h1 className="font-serif text-6xl font-bold text-gray-900 dark:text-dark-text mb-4">
          404
        </h1>
        <p className="text-lg text-gray-600 dark:text-dark-muted mb-8">
          Halaman yang Anda cari tidak ditemukan.
        </p>
        <Link href="/" className="btn-primary">
          <Home className="w-4 h-4 mr-2" />
          Kembali ke Beranda
        </Link>
      </div>
    </div>
  );
}
