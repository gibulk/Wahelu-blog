import { createServiceClient } from "@/lib/supabase";
import { NextRequest, NextResponse } from "next/server";

// GET: Fetch all subscribers (admin)
export async function GET() {
  const supabase = createServiceClient();

  const { data, error } = await supabase
    .from("subscribers")
    .select("*")
    .order("created_at", { ascending: false });

  if (error) {
    return NextResponse.json({ error: error.message }, { status: 500 });
  }

  return NextResponse.json(data);
}

// POST: Subscribe a new email
export async function POST(request: NextRequest) {
  const supabase = createServiceClient();
  const body = await request.json();

  if (!body.email) {
    return NextResponse.json({ error: "Email diperlukan" }, { status: 400 });
  }

  // Validate email format
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  if (!emailRegex.test(body.email)) {
    return NextResponse.json({ error: "Format email tidak valid" }, { status: 400 });
  }

  // Check if already subscribed
  const { data: existing } = await supabase
    .from("subscribers")
    .select("id")
    .eq("email", body.email.toLowerCase())
    .single();

  if (existing) {
    return NextResponse.json(
      { error: "Email ini sudah terdaftar sebagai subscriber" },
      { status: 409 }
    );
  }

  const { data, error } = await supabase
    .from("subscribers")
    .insert({ email: body.email.toLowerCase() })
    .select()
    .single();

  if (error) {
    return NextResponse.json({ error: error.message }, { status: 500 });
  }

  return NextResponse.json(data, { status: 201 });
}

// DELETE: Unsubscribe (admin)
export async function DELETE(request: NextRequest) {
  const supabase = createServiceClient();
  const { searchParams } = new URL(request.url);
  const id = searchParams.get("id");

  if (!id) {
    return NextResponse.json({ error: "Subscriber ID is required" }, { status: 400 });
  }

  const { error } = await supabase.from("subscribers").delete().eq("id", id);

  if (error) {
    return NextResponse.json({ error: error.message }, { status: 500 });
  }

  return NextResponse.json({ success: true });
}
