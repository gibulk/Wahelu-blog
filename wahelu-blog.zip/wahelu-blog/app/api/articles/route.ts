import { createServiceClient } from "@/lib/supabase";
import { NextRequest, NextResponse } from "next/server";
import { slugify } from "@/lib/utils";

// GET: Fetch articles (public = published only, admin = all)
export async function GET(request: NextRequest) {
  const supabase = createServiceClient();
  const { searchParams } = new URL(request.url);
  const all = searchParams.get("all") === "true";
  const category = searchParams.get("category");

  let query = supabase.from("articles").select("*");

  if (!all) {
    query = query.eq("status", "published");
  }

  if (category) {
    query = query.eq("category", category);
  }

  query = query.order("created_at", { ascending: false });

  const { data, error } = await query;

  if (error) {
    return NextResponse.json({ error: error.message }, { status: 500 });
  }

  return NextResponse.json(data);
}

// POST: Create a new article (admin)
export async function POST(request: NextRequest) {
  const supabase = createServiceClient();
  const body = await request.json();

  const slug = slugify(body.title);

  const articleData = {
    title: body.title,
    slug,
    excerpt: body.excerpt || "",
    content: body.content || "",
    category: body.category || "Geopolitik Asia-Pasifik",
    thumbnail_url: body.thumbnail_url || null,
    status: body.status || "draft",
    show_map: body.show_map || false,
    map_lat: body.map_lat || null,
    map_lng: body.map_lng || null,
    map_zoom: body.map_zoom || 5,
    published_at: body.status === "published" ? new Date().toISOString() : null,
  };

  const { data, error } = await supabase
    .from("articles")
    .insert(articleData)
    .select()
    .single();

  if (error) {
    return NextResponse.json({ error: error.message }, { status: 500 });
  }

  return NextResponse.json(data, { status: 201 });
}

// PUT: Update an article (admin)
export async function PUT(request: NextRequest) {
  const supabase = createServiceClient();
  const body = await request.json();

  if (!body.id) {
    return NextResponse.json({ error: "Article ID is required" }, { status: 400 });
  }

  const updateData: any = {};
  if (body.title) {
    updateData.title = body.title;
    updateData.slug = slugify(body.title);
  }
  if (body.excerpt !== undefined) updateData.excerpt = body.excerpt;
  if (body.content !== undefined) updateData.content = body.content;
  if (body.category) updateData.category = body.category;
  if (body.thumbnail_url !== undefined) updateData.thumbnail_url = body.thumbnail_url;
  if (body.status) {
    updateData.status = body.status;
    if (body.status === "published") {
      updateData.published_at = new Date().toISOString();
    }
  }
  if (body.show_map !== undefined) updateData.show_map = body.show_map;
  if (body.map_lat !== undefined) updateData.map_lat = body.map_lat;
  if (body.map_lng !== undefined) updateData.map_lng = body.map_lng;
  if (body.map_zoom !== undefined) updateData.map_zoom = body.map_zoom;

  const { data, error } = await supabase
    .from("articles")
    .update(updateData)
    .eq("id", body.id)
    .select()
    .single();

  if (error) {
    return NextResponse.json({ error: error.message }, { status: 500 });
  }

  return NextResponse.json(data);
}

// DELETE: Delete an article (admin)
export async function DELETE(request: NextRequest) {
  const supabase = createServiceClient();
  const { searchParams } = new URL(request.url);
  const id = searchParams.get("id");

  if (!id) {
    return NextResponse.json({ error: "Article ID is required" }, { status: 400 });
  }

  const { error } = await supabase.from("articles").delete().eq("id", id);

  if (error) {
    return NextResponse.json({ error: error.message }, { status: 500 });
  }

  return NextResponse.json({ success: true });
}
