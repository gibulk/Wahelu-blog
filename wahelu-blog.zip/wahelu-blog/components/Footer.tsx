import Link from "next/link";
import { Globe, Mail, Twitter } from "lucide-react";

export default function Footer() {
  return (
    <footer className="bg-gray-50 dark:bg-dark-card border-t border-gray-200 dark:border-dark-border mt-20">
      <div className="container-blog py-12">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {/* Brand */}
          <div>
            <div className="flex items-center gap-2 mb-4">
              <Globe className="w-6 h-6 text-primary-700 dark:text-primary-400" />
              <span className="font-serif text-lg font-bold text-gray-900 dark:text-dark-text">
                Wahelu
              </span>
            </div>
            <p className="text-sm text-gray-600 dark:text-dark-muted leading-relaxed">
              Platform analisis mendalam mengenai dinamika global, konflik perbatasan,
              kartografi, dan ekosistem Web3.
            </p>
          </div>

          {/* Navigation */}
          <div>
            <h4 className="font-serif font-semibold text-gray-900 dark:text-dark-text mb-4">
              Navigasi
            </h4>
            <ul className="space-y-2">
              <li>
                <Link
                  href="/"
                  className="text-sm text-gray-600 hover:text-primary-700 dark:text-dark-muted dark:hover:text-primary-400 transition-colors"
                >
                  Beranda
                </Link>
              </li>
              <li>
                <Link
                  href="/articles"
                  className="text-sm text-gray-600 hover:text-primary-700 dark:text-dark-muted dark:hover:text-primary-400 transition-colors"
                >
                  Semua Artikel
                </Link>
              </li>
              <li>
                <Link
                  href="/articles?category=Geopolitik+Asia-Pasifik"
                  className="text-sm text-gray-600 hover:text-primary-700 dark:text-dark-muted dark:hover:text-primary-400 transition-colors"
                >
                  Geopolitik Asia-Pasifik
                </Link>
              </li>
              <li>
                <Link
                  href="/articles?category=Web3+%26+Desentralisasi"
                  className="text-sm text-gray-600 hover:text-primary-700 dark:text-dark-muted dark:hover:text-primary-400 transition-colors"
                >
                  Web3 & Desentralisasi
                </Link>
              </li>
            </ul>
          </div>

          {/* Contact */}
          <div>
            <h4 className="font-serif font-semibold text-gray-900 dark:text-dark-text mb-4">
              Hubungi
            </h4>
            <ul className="space-y-3">
              <li>
                <a
                  href="mailto:hello@wahelu.com"
                  className="flex items-center gap-2 text-sm text-gray-600 hover:text-primary-700 dark:text-dark-muted dark:hover:text-primary-400 transition-colors"
                >
                  <Mail className="w-4 h-4" />
                  hello@wahelu.com
                </a>
              </li>
              <li>
                <a
                  href="https://twitter.com/wahelu"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center gap-2 text-sm text-gray-600 hover:text-primary-700 dark:text-dark-muted dark:hover:text-primary-400 transition-colors"
                >
                  <Twitter className="w-4 h-4" />
                  @wahelu
                </a>
              </li>
            </ul>
          </div>
        </div>

        <div className="mt-10 pt-6 border-t border-gray-200 dark:border-dark-border text-center">
          <p className="text-xs text-gray-500 dark:text-dark-muted">
            &copy; {new Date().getFullYear()} Wahelu. Seluruh hak cipta dilindungi.
          </p>
        </div>
      </div>
    </footer>
  );
}
