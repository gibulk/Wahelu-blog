"use client";

import { useState } from "react";
import { Wallet, Heart, CheckCircle, AlertCircle, Loader2 } from "lucide-react";

declare global {
  interface Window {
    ethereum?: any;
  }
}

export default function Web3Tipping() {
  const [walletAddress, setWalletAddress] = useState<string | null>(null);
  const [tipAmount, setTipAmount] = useState("0.001");
  const [status, setStatus] = useState<"idle" | "connecting" | "sending" | "success" | "error">("idle");
  const [message, setMessage] = useState("");

  const tippingWallet = process.env.NEXT_PUBLIC_TIPPING_WALLET || "0x0000000000000000000000000000000000000000";

  const connectWallet = async () => {
    if (!window.ethereum) {
      setStatus("error");
      setMessage("MetaMask tidak terdeteksi. Silakan install MetaMask terlebih dahulu.");
      return;
    }

    setStatus("connecting");
    try {
      const accounts = await window.ethereum.request({
        method: "eth_requestAccounts",
      });
      setWalletAddress(accounts[0]);
      setStatus("idle");
    } catch (err: any) {
      setStatus("error");
      setMessage(err.message || "Gagal menghubungkan wallet.");
    }
  };

  const sendTip = async () => {
    if (!window.ethereum || !walletAddress) return;

    setStatus("sending");
    try {
      const amountInWei = `0x${(parseFloat(tipAmount) * 1e18).toString(16)}`;

      await window.ethereum.request({
        method: "eth_sendTransaction",
        params: [
          {
            from: walletAddress,
            to: tippingWallet,
            value: amountInWei,
          },
        ],
      });

      setStatus("success");
      setMessage("Terima kasih atas dukungan Anda! 🎉");
    } catch (err: any) {
      setStatus("error");
      setMessage(err.message || "Transaksi gagal.");
    }
  };

  const tipOptions = ["0.001", "0.005", "0.01", "0.05"];

  return (
    <div className="card p-6">
      <div className="flex items-center gap-2 mb-4">
        <Heart className="w-5 h-5 text-red-500" />
        <h3 className="font-serif font-semibold text-gray-900 dark:text-dark-text">
          Dukung Penulis (Web3)
        </h3>
      </div>

      <p className="text-sm text-gray-600 dark:text-dark-muted mb-4">
        Kirim tip melalui MetaMask untuk mendukung konten berkualitas.
      </p>

      {!walletAddress ? (
        <button
          onClick={connectWallet}
          disabled={status === "connecting"}
          className="w-full btn-primary flex items-center justify-center gap-2"
        >
          {status === "connecting" ? (
            <Loader2 className="w-4 h-4 animate-spin" />
          ) : (
            <Wallet className="w-4 h-4" />
          )}
          Hubungkan MetaMask
        </button>
      ) : (
        <div className="space-y-4">
          <div className="flex items-center gap-2 text-xs text-gray-500 dark:text-dark-muted bg-gray-50 dark:bg-dark-bg p-2 rounded-lg">
            <Wallet className="w-3.5 h-3.5 flex-shrink-0" />
            <span className="truncate">{walletAddress}</span>
          </div>

          {/* Tip Amount Options */}
          <div className="grid grid-cols-4 gap-2">
            {tipOptions.map((amount) => (
              <button
                key={amount}
                onClick={() => setTipAmount(amount)}
                className={`py-2 px-1 text-xs font-medium rounded-lg border transition-colors ${
                  tipAmount === amount
                    ? "border-primary-500 bg-primary-50 text-primary-700 dark:bg-primary-900/30 dark:text-primary-300 dark:border-primary-600"
                    : "border-gray-200 dark:border-dark-border text-gray-600 dark:text-dark-muted hover:border-primary-300"
                }`}
              >
                {amount} ETH
              </button>
            ))}
          </div>

          {/* Custom Amount */}
          <input
            type="number"
            step="0.001"
            min="0.001"
            value={tipAmount}
            onChange={(e) => setTipAmount(e.target.value)}
            className="input-field text-sm"
            placeholder="Jumlah ETH"
          />

          <button
            onClick={sendTip}
            disabled={status === "sending"}
            className="w-full btn-primary flex items-center justify-center gap-2"
          >
            {status === "sending" ? (
              <Loader2 className="w-4 h-4 animate-spin" />
            ) : (
              <Heart className="w-4 h-4" />
            )}
            Kirim {tipAmount} ETH
          </button>
        </div>
      )}

      {status === "success" && (
        <div className="mt-3 flex items-center gap-2 text-green-600 dark:text-green-400 text-sm">
          <CheckCircle className="w-4 h-4" />
          {message}
        </div>
      )}

      {status === "error" && (
        <div className="mt-3 flex items-center gap-2 text-red-600 dark:text-red-400 text-sm">
          <AlertCircle className="w-4 h-4" />
          {message}
        </div>
      )}
    </div>
  );
}
