"use client";

import { useState } from "react";
import { Mail, CheckCircle, Loader2 } from "lucide-react";

export default function Newsletter() {
  const [email, setEmail] = useState("");
  const [status, setStatus] = useState<"idle" | "loading" | "success" | "error">("idle");
  const [message, setMessage] = useState("");

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!email) return;

    setStatus("loading");
    try {
      const res = await fetch("/api/subscribers", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email }),
      });

      const data = await res.json();

      if (res.ok) {
        setStatus("success");
        setMessage("Terima kasih! Anda berhasil berlangganan.");
        setEmail("");
      } else {
        setStatus("error");
        setMessage(data.error || "Terjadi kesalahan. Silakan coba lagi.");
      }
    } catch {
      setStatus("error");
      setMessage("Terjadi kesalahan jaringan. Silakan coba lagi.");
    }
  };

  return (
    <section className="bg-gradient-to-br from-primary-700 to-primary-900 dark:from-primary-900 dark:to-dark-bg rounded-2xl p-8 md:p-12 text-white">
      <div className="max-w-2xl mx-auto text-center">
        <Mail className="w-10 h-10 mx-auto mb-4 opacity-80" />
        <h2 className="font-serif text-2xl md:text-3xl font-bold mb-3">
          Berlangganan Newsletter
        </h2>
        <p className="text-primary-100 mb-8 text-sm md:text-base">
          Dapatkan analisis geopolitik dan insight Web3 terbaru langsung di inbox Anda.
          Tanpa spam, hanya konten berkualitas.
        </p>

        {status === "success" ? (
          <div className="flex items-center justify-center gap-2 text-green-300">
            <CheckCircle className="w-5 h-5" />
            <span>{message}</span>
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="flex flex-col sm:flex-row gap-3 max-w-md mx-auto">
            <input
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="email@anda.com"
              required
              className="flex-1 px-4 py-3 rounded-lg bg-white/10 border border-white/20 text-white placeholder-white/50 focus:outline-none focus:ring-2 focus:ring-white/30 backdrop-blur-sm"
            />
            <button
              type="submit"
              disabled={status === "loading"}
              className="px-6 py-3 bg-white text-primary-800 font-semibold rounded-lg hover:bg-primary-50 transition-colors disabled:opacity-50 flex items-center justify-center gap-2"
            >
              {status === "loading" ? (
                <Loader2 className="w-4 h-4 animate-spin" />
              ) : (
                "Langganan"
              )}
            </button>
          </form>
        )}

        {status === "error" && (
          <p className="mt-3 text-red-300 text-sm">{message}</p>
        )}
      </div>
    </section>
  );
}
