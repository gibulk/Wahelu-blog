import Link from "next/link";
import { formatDate, truncate } from "@/lib/utils";
import { Article } from "@/lib/types";
import { Calendar, ArrowRight } from "lucide-react";

interface ArticleCardProps {
  article: Article;
  featured?: boolean;
}

export default function ArticleCard({ article, featured = false }: ArticleCardProps) {
  return (
    <Link href={`/articles/${article.slug}`} className="block group">
      <article className={`card ${featured ? "md:flex" : ""}`}>
        {/* Thumbnail */}
        {article.thumbnail_url && (
          <div
            className={`relative overflow-hidden ${
              featured ? "md:w-1/2 h-48 md:h-auto" : "h-48"
            }`}
          >
            <img
              src={article.thumbnail_url}
              alt={article.title}
              className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-black/20 to-transparent" />
          </div>
        )}

        {/* Content */}
        <div className={`p-6 ${featured ? "md:w-1/2 md:flex md:flex-col md:justify-center" : ""}`}>
          <span className="badge-category mb-3">{article.category}</span>

          <h3
            className={`font-serif font-bold text-gray-900 dark:text-dark-text group-hover:text-primary-700 dark:group-hover:text-primary-400 transition-colors mb-3 ${
              featured ? "text-2xl" : "text-lg"
            }`}
          >
            {article.title}
          </h3>

          <p className="text-gray-600 dark:text-dark-muted text-sm leading-relaxed mb-4">
            {truncate(article.excerpt, featured ? 200 : 120)}
          </p>

          <div className="flex items-center justify-between">
            <div className="flex items-center gap-1.5 text-xs text-gray-500 dark:text-dark-muted">
              <Calendar className="w-3.5 h-3.5" />
              {article.published_at ? formatDate(article.published_at) : "Draft"}
            </div>
            <span className="flex items-center gap-1 text-xs font-medium text-primary-700 dark:text-primary-400 group-hover:gap-2 transition-all">
              Baca <ArrowRight className="w-3.5 h-3.5" />
            </span>
          </div>
        </div>
      </article>
    </Link>
  );
}
