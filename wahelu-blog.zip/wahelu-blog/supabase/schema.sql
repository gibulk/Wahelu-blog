-- ============================================
-- WAHELU BLOG - Database Schema
-- Jalankan SQL ini di Supabase SQL Editor
-- ============================================

-- 1. Tabel Articles
CREATE TABLE IF NOT EXISTS articles (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  title TEXT NOT NULL,
  slug TEXT NOT NULL UNIQUE,
  excerpt TEXT NOT NULL DEFAULT '',
  content TEXT NOT NULL DEFAULT '',
  category TEXT NOT NULL DEFAULT 'Geopolitik Asia-Pasifik',
  thumbnail_url TEXT,
  status TEXT NOT NULL DEFAULT 'draft' CHECK (status IN ('draft', 'published')),
  show_map BOOLEAN NOT NULL DEFAULT false,
  map_lat DOUBLE PRECISION,
  map_lng DOUBLE PRECISION,
  map_zoom INTEGER DEFAULT 5,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  published_at TIMESTAMPTZ,
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- 2. Tabel Subscribers
CREATE TABLE IF NOT EXISTS subscribers (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  email TEXT NOT NULL UNIQUE,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 3. Index untuk performa
CREATE INDEX IF NOT EXISTS idx_articles_slug ON articles(slug);
CREATE INDEX IF NOT EXISTS idx_articles_status ON articles(status);
CREATE INDEX IF NOT EXISTS idx_articles_category ON articles(category);
CREATE INDEX IF NOT EXISTS idx_articles_published_at ON articles(published_at DESC);
CREATE INDEX IF NOT EXISTS idx_subscribers_email ON subscribers(email);

-- 4. Function untuk auto-update updated_at
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = NOW();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER update_articles_updated_at
  BEFORE UPDATE ON articles
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();

-- 5. Row Level Security (RLS)
ALTER TABLE articles ENABLE ROW LEVEL SECURITY;
ALTER TABLE subscribers ENABLE ROW LEVEL SECURITY;

-- Policy: Semua orang bisa baca artikel yang published
CREATE POLICY "Public can read published articles"
  ON articles FOR SELECT
  USING (status = 'published');

-- Policy: Authenticated users (admin) bisa CRUD semua artikel
CREATE POLICY "Admin can do everything with articles"
  ON articles FOR ALL
  USING (auth.role() = 'authenticated')
  WITH CHECK (auth.role() = 'authenticated');

-- Policy: Semua orang bisa subscribe
CREATE POLICY "Anyone can subscribe"
  ON subscribers FOR INSERT
  WITH CHECK (true);

-- Policy: Admin bisa lihat subscribers
CREATE POLICY "Admin can read subscribers"
  ON subscribers FOR SELECT
  USING (auth.role() = 'authenticated');

-- 6. Storage bucket untuk thumbnails (jalankan terpisah jika perlu)
-- INSERT INTO storage.buckets (id, name, public) VALUES ('thumbnails', 'thumbnails', true);

-- 7. Seed data contoh (opsional)
INSERT INTO articles (title, slug, excerpt, content, category, status, published_at, show_map, map_lat, map_lng, map_zoom)
VALUES
(
  'Dinamika Geopolitik Laut China Selatan 2026',
  'dinamika-geopolitik-laut-china-selatan-2026',
  'Analisis mendalam tentang klaim tumpang tindih dan eskalasi militer di kawasan Laut China Selatan yang melibatkan beberapa negara ASEAN dan kekuatan besar dunia.',
  '## Pendahuluan

Laut China Selatan tetap menjadi salah satu titik api geopolitik paling kritis di dunia. Dengan klaim tumpang tindih dari enam negara dan dua entitas, kawasan ini menjadi arena persaingan strategis yang melibatkan kepentingan ekonomi, militer, dan diplomatik.

## Peta Kekuatan

Beberapa negara utama yang terlibat dalam sengketa ini antara lain:

- **Tiongkok**: Mengklaim hampir seluruh Laut China Selatan berdasarkan "nine-dash line"
- **Vietnam**: Mengklaim Kepulauan Spratly dan Paracel
- **Filipina**: Mengklaim sebagian Kepulauan Spratly dan Scarborough Shoal
- **Malaysia**: Mengklaim sebagian Kepulauan Spratly
- **Brunei**: Mengklaim zona ekonomi eksklusif di selatan

## Eskalasi Terkini

Tahun 2026 menyaksikan peningkatan signifikan dalam aktivitas militer di kawasan ini. Pembangunan pulau buatan oleh Tiongkok terus berlanjut, sementara negara-negara ASEAN memperkuat kerja sama pertahanan maritim mereka.

## Implikasi Ekonomi

Laut China Selatan merupakan jalur perdagangan vital yang dilalui oleh sepertiga perdagangan maritim global. Ketidakstabilan di kawasan ini berpotensi mengganggu rantai pasok global dan mempengaruhi harga komoditas.

## Kesimpulan

Resolusi damai atas sengketa Laut China Selatan memerlukan pendekatan multilateral yang melibatkan semua pihak. ASEAN perlu memperkuat mekanisme Code of Conduct (CoC) sebagai kerangka kerja diplomatik utama.',
  'Geopolitik Asia-Pasifik',
  'published',
  NOW(),
  true,
  12.0,
  114.0,
  5
),
(
  'Web3 dan Masa Depan Desentralisasi Informasi',
  'web3-masa-depan-desentralisasi-informasi',
  'Bagaimana teknologi blockchain dan Web3 mengubah cara kita mengakses, memverifikasi, dan mendistribusikan informasi di era digital.',
  '## Era Baru Informasi

Web3 bukan sekadar evolusi teknologi, melainkan revolusi paradigma dalam cara kita berinteraksi dengan informasi digital. Dengan fondasi blockchain, Web3 menawarkan transparansi, keamanan, dan desentralisasi yang tidak mungkin dicapai oleh arsitektur web tradisional.

## Pilar Utama Web3

### 1. Desentralisasi
Tidak ada entitas tunggal yang mengontrol data. Informasi tersebar di jaringan node yang saling terhubung.

### 2. Tokenisasi
Aset digital dapat direpresentasikan sebagai token, memungkinkan kepemilikan dan perdagangan yang transparan.

### 3. Smart Contracts
Kontrak otomatis yang dieksekusi tanpa perantara, mengurangi biaya dan meningkatkan efisiensi.

## Implikasi untuk Jurnalisme

Web3 membuka peluang baru untuk jurnalisme independen:
- **Verifikasi sumber** melalui blockchain
- **Monetisasi konten** langsung dari pembaca ke penulis
- **Perlindungan hak cipta** yang tidak dapat dimanipulasi

## Tantangan

Meskipun menjanjikan, adopsi Web3 masih menghadapi beberapa hambatan signifikan termasuk skalabilitas, pengalaman pengguna, dan regulasi yang belum matang.

## Pandangan ke Depan

Integrasi Web3 dalam ekosistem informasi akan terus berkembang. Kunci keberhasilannya terletak pada keseimbangan antara inovasi teknologi dan aksesibilitas bagi pengguna umum.',
  'Web3 & Desentralisasi',
  'published',
  NOW(),
  false,
  NULL,
  NULL,
  NULL
),
(
  'Peta Politik Timur Tengah: Aliansi Baru Pasca-2025',
  'peta-politik-timur-tengah-aliansi-baru',
  'Pergeseran aliansi strategis di Timur Tengah menciptakan konfigurasi geopolitik baru yang mempengaruhi keseimbangan kekuatan global.',
  '## Lanskap Baru Timur Tengah

Timur Tengah memasuki era baru dengan pergeseran aliansi yang signifikan. Normalisasi hubungan antara beberapa negara Arab dan Israel, dikombinasikan dengan kebangkitan pengaruh regional Iran dan Turki, menciptakan dinamika yang kompleks.

## Aktor Utama

### Arab Saudi
Kerajaan ini terus melakukan diversifikasi ekonomi melalui Vision 2030 sambil mempertahankan peran sebagai pemimpin dunia Arab.

### Iran
Program nuklir dan pengaruh regional melalui proksi tetap menjadi faktor destabilisasi utama.

### Turki
Ankara memainkan peran ganda sebagai anggota NATO dan aktor independen dengan ambisi Ottoman-era.

### Israel
Normalisasi dengan negara-negara Arab membuka peluang ekonomi baru namun konflik Palestina tetap menjadi isu sentral.

## Implikasi Global

Pergeseran ini mempengaruhi pasar energi global, rute perdagangan, dan arsitektur keamanan internasional. Kekuatan besar seperti AS, Rusia, dan Tiongkok terus bersaing untuk pengaruh di kawasan ini.

## Kesimpulan

Timur Tengah akan tetap menjadi kawasan kunci dalam geopolitik global. Pemahaman mendalam tentang dinamika lokal dan regional sangat penting untuk menganalisis tren global.',
  'Ekonomi-Politik Global',
  'published',
  NOW(),
  true,
  29.0,
  47.0,
  4
);
