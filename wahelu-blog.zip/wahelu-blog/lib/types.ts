export interface Article {
  id: string;
  title: string;
  slug: string;
  excerpt: string;
  content: string;
  category: string;
  thumbnail_url: string | null;
  status: "draft" | "published";
  show_map: boolean;
  map_lat: number | null;
  map_lng: number | null;
  map_zoom: number | null;
  created_at: string;
  published_at: string | null;
  updated_at: string;
}

export interface Subscriber {
  id: string;
  email: string;
  created_at: string;
}

export const CATEGORIES = [
  "Geopolitik Asia-Pasifik",
  "Ekonomi-Politik Global",
  "Web3 & Desentralisasi",
  "Konflik & Perbatasan",
  "Kartografi & Geografi",
] as const;

export type Category = (typeof CATEGORIES)[number];
